window.onload = function(){
	var preloader = document.getElementById('preloader');

	preloader.style.visibility = 'hidden';
	preloader.style.opacity = '0';
}